package com.chidi.security.dto.responses;

import com.chidi.security.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class UserAccountResponse {

    private String name;
    private String username;
    private Status status;





}
