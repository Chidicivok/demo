package com.chidi.security.dto.responses;

import lombok.AllArgsConstructor;
import lombok.Getter;
import java.time.LocalDateTime;

@AllArgsConstructor
@Getter
public class OTPResponse {

    private String value;
    private LocalDateTime expiresAt;
    private Boolean isActive;
    private String username;

}
