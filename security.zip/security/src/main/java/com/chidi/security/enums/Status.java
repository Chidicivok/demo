package com.chidi.security.enums;

public enum Status {
    ACTIVE,
    INACTIVE
}
