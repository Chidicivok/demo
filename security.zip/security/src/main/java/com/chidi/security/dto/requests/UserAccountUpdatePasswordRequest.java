package com.chidi.security.dto.requests;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class UserAccountUpdatePasswordRequest {


    @NotBlank(message = "Password is required")
    @Size(min = 8, max = 12, message = "Password must contain between 8-12 characters")
    @Pattern(regexp = "^[a-zA-Z!@#$%^&*_-]+$", message = "Password may contain alpha numeric characters and some special symbols")
    private String password;
}
