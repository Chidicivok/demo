package com.chidi.security.services.interfaces;

public interface OTPServiceInterface {
}
