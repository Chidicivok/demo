package com.chidi.security.services.interfaces;

import com.chidi.security.dto.requests.OTPCreateRequest;
import com.chidi.security.dto.requests.OTPVerifyRequest;
import com.chidi.security.dto.responses.OTPResponse;

public interface OTPServiceInterface {

    // create otp
    OTPResponse createOTP(OTPCreateRequest request);

    // verify otp
    boolean verifyOTP(OTPVerifyRequest request);
}