package com.chidi.security.dto.requests;


import com.chidi.security.entities.UserAccount;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;


@AllArgsConstructor
@Setter
@Getter
public class OTPCreateRequest {

    @NotBlank(message = "OTP Value is needed")
    @Column(name = "value", nullable = false)
    private String value;

    @NotNull(message = "DateTime is required")
    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    @NotNull(message = "OTP is_active is needed")
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    private UserAccount userAccount;
}
