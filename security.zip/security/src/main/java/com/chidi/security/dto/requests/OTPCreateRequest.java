package com.chidi.security.dto.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class OTPCreateRequest {

    @NotBlank(message = "Username is needed")
    private String username;

}
