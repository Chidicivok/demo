package com.chidi.security.repositories;

import com.chidi.security.entities.OTP;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface OTPRepository extends JpaRepository<OTP, Long> {

    boolean existsByValueAndIsActive(String value, Boolean isActive);

    Optional<OTP> findByValueAndIsActiveAndUserAccount_Username(String value, Boolean isActive, String userAccountUsername);
}
