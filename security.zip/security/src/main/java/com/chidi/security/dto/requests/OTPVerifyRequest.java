package com.chidi.security.dto.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class OTPVerifyRequest {

    @NotBlank(message = "OTP Value is needed")
    private String username;

    @NotBlank(message = "OTP Value is needed")
    private String value;

}
