package com.chidi.security.dto.requests;

import com.chidi.security.entities.UserAccount;
import jakarta.persistence.Column;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class OTPUpdateRequest {

    @NotNull(message = "OTP is_active is needed")
    @Column(name = "is_active", nullable = false)
    private Boolean isActive;


}
