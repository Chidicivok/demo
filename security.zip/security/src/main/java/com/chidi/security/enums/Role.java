package com.chidi.security.enums;

public enum Role {
    USER,
    ADMIN
}
