package com.chidi.security.services.interfaces;

import com.chidi.security.dto.requests.UserAccountCreateRequest;
import com.chidi.security.dto.requests.UserAccountUpdateNameRequest;
import com.chidi.security.dto.requests.UserAccountUpdatePasswordRequest;
import com.chidi.security.dto.responses.UserAccountResponse;
import com.chidi.security.entities.UserAccount;
import org.springframework.stereotype.Component;

@Component
public interface UserAccountServiceInterface {

        UserAccountResponse createUserAccount(UserAccountCreateRequest request);

        UserAccountResponse updateUserAccountName(UserAccountUpdateNameRequest request);

        UserAccountResponse updateUserAccountPassword(UserAccountUpdatePasswordRequest request);




}
