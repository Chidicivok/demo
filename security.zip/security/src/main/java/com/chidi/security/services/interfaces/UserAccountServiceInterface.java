package com.chidi.security.services.interfaces;

import com.chidi.security.dto.requests.LoginRequest;
import com.chidi.security.dto.requests.UserAccountCreateRequest;
import com.chidi.security.dto.requests.UserAccountUpdateNameRequest;
import com.chidi.security.dto.requests.UserAccountUpdatePasswordRequest;
import com.chidi.security.dto.responses.UserAccountResponse;
import com.chidi.security.enums.Status;

import java.util.List;

public interface UserAccountServiceInterface {

    // create user account
    UserAccountResponse createUserAccount(UserAccountCreateRequest request);

    // verify login
    UserAccountResponse login(LoginRequest request);

    // get user by username
    UserAccountResponse getUserByUsername(String username);

    // update name
    UserAccountResponse updateName(UserAccountUpdateNameRequest request, String username);

    // update password
    UserAccountResponse updatePassword(UserAccountUpdatePasswordRequest request, String username);

    // get all users
    List<UserAccountResponse> getAllUsers();

    // activate / deactivate user
    UserAccountResponse updateStatus(String username, Status status);
}

