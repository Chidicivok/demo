package com.chidi.security.dto.requests;


import jakarta.validation.constraints.NotBlank;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class UserAccountCreateRequest {
    @NotBlank(message = "Name is required")
    @Size(min = 3, max = 100, message = "Name must contain between 3-100 characters")
    @Pattern(regexp = "^[a-zA-Z]+$", message = "Name must contain only alphabets")
    private String name;

    @NotBlank(message = "Name is required")
    @Size(min = 3, max = 100, message = "Username must contain between 3-100 characters")
    @Pattern(regexp = "^[a-zA-Z]+$", message = "Username may contain only alphanumeric values")
    private String username;

    @NotBlank(message = "Name is required")
    @Size(min = 8, max = 12, message = "Password must contain between 8-12 characters")
    @Pattern(regexp = "^[a-zA-Z!@#$%^&*_-]+$", message = "Password may contain alpha numeric characters and some special symbols")
    private String password;

    // activate user account in servgices

}
