package com.chidi.security.services.implementations;

import com.chidi.security.dto.requests.OTPCreateRequest;
import com.chidi.security.dto.requests.OTPVerifyRequest;
import com.chidi.security.dto.responses.OTPResponse;
import com.chidi.security.entities.OTP;
import com.chidi.security.entities.UserAccount;
import com.chidi.security.mappers.OTPMapper;
import com.chidi.security.repositories.OTPRepository;
import com.chidi.security.repositories.UserAccountRepository;
import com.chidi.security.services.interfaces.OTPServiceInterface;
import com.chidi.security.utilities.OTPGenerator;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;


@Service
@Transactional
@AllArgsConstructor
public class OTPServiceImplementation implements OTPServiceInterface {


    private final OTPRepository otpRepository;
    private final UserAccountRepository userAccountRepository;
    private final OTPMapper otpMapper;

    // create otp
    @Override
    public OTPResponse createOTP(OTPCreateRequest request) {

        // find the user that requested for the otp
        UserAccount userAccount = userAccountRepository.findByUsername(request.getUsername()).orElseThrow(
                () -> new RuntimeException("Username does not exist")
        );

        // generate otp
        String generatedOTP = OTPGenerator.generateOTP();

        // create otp object
        OTP otp = otpMapper.createToEntity(generatedOTP, userAccount);

        // save otp to db
        OTP savedOTP = otpRepository.save(otp);


        // display otp on console
        System.out.println("=================================");
        System.out.println("OTP for " + userAccount.getUsername() + ": " + generatedOTP);
        System.out.println("=================================");

        return otpMapper.toResponse(savedOTP);
    }


    // verify otp
    @Override
    public boolean verifyOTP(OTPVerifyRequest request) {

        // get otp object
        OTP otp = otpRepository.findByValueAndIsActiveAndUserAccount_Username(request.getValue(), true, request.getUsername()).orElseThrow(
                () -> new RuntimeException("Invalid OTP")
        );

        // check if it has expired
        if (otp.getExpiresAt().isBefore(LocalDateTime.now())) {
            otp.setIsActive(false);
            otpRepository.save(otp);
            throw new RuntimeException("OTP has expired");
        }

        // deactivate
        otp.setIsActive(false);

        // update otp table
        otpRepository.save(otp);

        return true;
    }
}


