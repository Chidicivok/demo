package com.chidi.security.mappers;

import com.chidi.security.dto.requests.*;
import com.chidi.security.dto.responses.OTPResponse;
import com.chidi.security.dto.responses.UserAccountResponse;
import com.chidi.security.entities.OTP;
import com.chidi.security.entities.UserAccount;

import java.time.LocalDateTime;

public class OTPMapper {

    public OTP createToEntity(OTPCreateRequest request, UserAccount userAccount) {

        OTP otp = new OTP();

        otp.setValue(request.getValue());
        otp.setExpiresAt(request.getExpiresAt());
        otp.setIsActive(request.getIsActive());
        otp.setUserAccount(userAccount);

        return otp;

    }


    public void updateOTPToEntity(OTPUpdateRequest request, OTP otp) {

        otp.setIsActive(request.getIsActive());


    }


    public OTPResponse toResponse(OTP otp) {

        return new OTPResponse(
                otp.getValue(),
                otp.getExpiresAt(),
                otp.getIsActive(),
                otp.getUserAccount().getUsername()
        );

    }

}
