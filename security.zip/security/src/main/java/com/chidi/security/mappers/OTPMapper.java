package com.chidi.security.mappers;

import com.chidi.security.dto.requests.*;
import com.chidi.security.dto.responses.OTPResponse;
import com.chidi.security.entities.OTP;
import com.chidi.security.entities.UserAccount;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class OTPMapper {

    // convert create request to otp entity
    public OTP createToEntity(String generatedOTP, UserAccount userAccount) {

        // otp object
        OTP otp = new OTP();

        // set params to entity \
        otp.setValue(generatedOTP);
        otp.setExpiresAt(LocalDateTime.now().plusMinutes(5));
        otp.setIsActive(true);
        otp.setUserAccount(userAccount);

        // return the otp object
        return otp;
    }

    // otp response
    public OTPResponse toResponse(OTP otp) {

        return new OTPResponse(
                otp.getValue(),
                otp.getExpiresAt(),
                otp.getIsActive(),
                otp.getUserAccount().getUsername()
        );

    }

}
