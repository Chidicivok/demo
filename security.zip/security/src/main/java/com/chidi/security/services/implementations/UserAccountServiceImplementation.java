package com.chidi.security.services.implementations;

import com.chidi.security.dto.requests.UserAccountCreateRequest;
import com.chidi.security.dto.requests.UserAccountUpdateNameRequest;
import com.chidi.security.dto.requests.UserAccountUpdatePasswordRequest;
import com.chidi.security.dto.responses.UserAccountResponse;
import com.chidi.security.entities.UserAccount;
import com.chidi.security.mappers.UserAccountMapper;
import com.chidi.security.repositories.UserAccountRepository;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;


@Service
@Transactional
@AllArgsConstructor
public class UserAccountServiceImplementation {


    private UserAccountRepository userAccountRepository;
    private UserAccountMapper userAccountMapper;


    // find if user exits by username already as helper method
    public Optional<UserAccount> findUserByUsername (String aUsername) {

        Optional<UserAccount> foundUser = userAccountRepository.findByUsername(aUsername);
        if(foundUser.isEmpty()) throw new RuntimeException("Username does not exist");
        return foundUser;


    }




    @Transactional
    public UserAccountResponse createUserAccount(UserAccountCreateRequest request) {

        if(userAccountRepository.existsByUsername(request.getUsername())) throw new RuntimeException("Username already taken");
        UserAccount newUser = userAccountMapper.createToEntity(request);
        return userAccountMapper.toResponse(userAccountRepository.save(newUser));


    }


    public UserAccountResponse updateName(UserAccountUpdateNameRequest request, String username) {

       UserAccount userAccount = userAccountRepository.findBy(username);
        userAccount.setName(request.getName());
        return userAccountMapper.toResponse(userAccountRepository.save(userAccount));

    }

    public UserAccountResponse updatePassword(UserAccountUpdatePasswordRequest request, String username) {

        UserAccount userAccount = userAccountRepository.findBy(username);
        userAccount.setPassword(request.getPassword());
        return userAccountMapper.toResponse(userAccountRepository.save(userAccount));

    }




}
