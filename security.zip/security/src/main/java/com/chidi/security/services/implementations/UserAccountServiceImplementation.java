package com.chidi.security.services.implementations;

import com.chidi.security.dto.requests.LoginRequest;
import com.chidi.security.dto.requests.UserAccountCreateRequest;
import com.chidi.security.dto.requests.UserAccountUpdateNameRequest;
import com.chidi.security.dto.requests.UserAccountUpdatePasswordRequest;
import com.chidi.security.dto.responses.UserAccountResponse;
import com.chidi.security.entities.UserAccount;
import com.chidi.security.enums.Role;
import com.chidi.security.enums.Status;
import com.chidi.security.mappers.UserAccountMapper;
import com.chidi.security.repositories.UserAccountRepository;
import com.chidi.security.services.interfaces.UserAccountServiceInterface;

import jakarta.transaction.Transactional;

import lombok.AllArgsConstructor;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
@AllArgsConstructor
public class UserAccountServiceImplementation
        implements UserAccountServiceInterface {


    private final UserAccountRepository userAccountRepository;
    private final UserAccountMapper userAccountMapper;
    private final PasswordEncoder passwordEncoder;


    // helper method to find user by username
    private UserAccount findUserByUsername(String username) {

        return userAccountRepository.findByUsername(username).orElseThrow(
                () -> new RuntimeException("User does not exist ")
        );
    }


    // create user
    @Override
    public UserAccountResponse createUserAccount(UserAccountCreateRequest request) {

        // Prevent duplicate usernames.
        if (userAccountRepository.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already taken");
        }

        // create user account entty using the mapper
        UserAccount newUser = userAccountMapper.createToEntity(request);

        // encode the passowrd and store
        String encodedPassword = passwordEncoder.encode(request.getPassword());

        // set encoded password
        newUser.setPassword(encodedPassword);

        // default all users to user role
        newUser.setRole(Role.USER);

        // active on create
        newUser.setStatus(Status.ACTIVE);


        UserAccount savedUser = userAccountRepository.save(newUser);


        return userAccountMapper.toResponse(savedUser);
    }


    // login user
    @Override
    public UserAccountResponse login(LoginRequest request) {

        // find if user actually exits
        UserAccount userAccount = findUserByUsername(request.getUsername());

        // check if that user is active or not
        if (userAccount.getStatus() == Status.INACTIVE) throw new RuntimeException("This user has been deactivated ");

        // check if password hashes match
        boolean passwordMatches = passwordEncoder.matches(request.getPassword(), userAccount.getPassword());

        if (!passwordMatches) throw new RuntimeException("Wrong password");

        return userAccountMapper.toResponse(userAccount);
    }


    // return for profile
    @Override
    public UserAccountResponse getUserByUsername(String username) {
        UserAccount userAccount = findUserByUsername(username);
        return userAccountMapper.toResponse(userAccount);
    }


    // update name
    @Override
    public UserAccountResponse updateName(UserAccountUpdateNameRequest request, String username) {

        UserAccount userAccount = findUserByUsername(username);
        userAccountMapper.updateNameToEntity(request, userAccount);
        UserAccount savedUser = userAccountRepository.save(userAccount);
        return userAccountMapper.toResponse(savedUser);
    }


    // change password
    @Override
    public UserAccountResponse updatePassword(UserAccountUpdatePasswordRequest request, String username) {

        UserAccount userAccount = findUserByUsername(username);
        String encodedPassword = passwordEncoder.encode(request.getPassword());
        userAccount.setPassword(encodedPassword);
        UserAccount savedUser = userAccountRepository.save(userAccount);

        return userAccountMapper.toResponse(savedUser);
    }


    // get all users
    @Override
    public List<UserAccountResponse> getAllUsers() {

        return userAccountRepository
                .findAll()
                .stream()
                .map(userAccountMapper::toResponse)
                .toList();
    }


    // change status
    @Override
    public UserAccountResponse updateStatus(String username, Status status) {

        UserAccount userAccount = findUserByUsername(username);
        userAccount.setStatus(status);

        UserAccount savedUser = userAccountRepository.save(userAccount);
        return userAccountMapper.toResponse(savedUser);
    }
}


