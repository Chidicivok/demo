package com.chidi.security.entities;


import com.chidi.security.enums.Status;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(
        name = "user",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_user_username", columnNames = "username")
        }
)
@NoArgsConstructor
@Getter
@Setter
public class UserAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "name", nullable = false, length = 100)
    @Size(min = 3, max = 100, message = "Name must contain between 3-100 characters")
    @Pattern(regexp = "^[a-zA-Z]+$", message = "Name must contain only alphabets")
    private String name;


    @Column(name = "username", nullable = false, length = 100)
    @Size(min = 3, max = 100, message = "Username must contain between 3-100 characters")
    @Pattern(regexp = "^[a-zA-Z]+$", message = "Username may contain only alphanumeric values")
    private String username;

    @Column(name = "password", nullable = false, length = 12)
    @Size(min = 8, max = 12, message = "Password must contain between 8-12 characters")
    @Pattern(regexp = "^[a-zA-Z!@#$%^&*_-]+$", message = "Password may contain alpha numeric characters and some special symbols")
    private String password;

    @NotNull(message = "Status cannot be null")
    private Status status;

}
