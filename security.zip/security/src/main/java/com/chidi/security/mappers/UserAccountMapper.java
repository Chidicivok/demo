package com.chidi.security.mappers;


import com.chidi.security.dto.requests.UserAccountCreateRequest;
import com.chidi.security.dto.requests.UserAccountUpdateNameRequest;
import com.chidi.security.dto.requests.UserAccountUpdatePasswordRequest;
import com.chidi.security.dto.responses.UserAccountResponse;
import com.chidi.security.entities.UserAccount;
import org.springframework.stereotype.Component;

@Component
public class UserAccountMapper {

    public UserAccount createToEntity(UserAccountCreateRequest request) {

        UserAccount userAccount = new UserAccount();

        userAccount.setName(request.getName());
        userAccount.setUsername(request.getUsername());
        userAccount.setPassword(request.getPassword());

        return userAccount;

    }


    public void updateNameToEntity(UserAccountUpdateNameRequest request, UserAccount userAccount) {
        userAccount.setName(request.getName());
    }

    public void updatePasswordToEntity(UserAccountUpdatePasswordRequest request, UserAccount userAccount) {
        userAccount.setPassword(request.getPassword());
    }

    public UserAccountResponse toResponse(UserAccount userAccount) {
        return new UserAccountResponse(
                userAccount.getName(),
                userAccount.getUsername(),
                userAccount.getStatus()
        );

    }


}
