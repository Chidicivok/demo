package com.chidi.security.dto.requests;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class LoginRequest {

    @NotBlank(message = "Name is required")
    private String username;

    @NotBlank(message = "Name is required")
    private String password;

}
