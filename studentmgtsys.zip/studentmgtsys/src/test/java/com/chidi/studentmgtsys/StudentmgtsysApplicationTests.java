package com.chidi.studentmgtsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmgtsysApplicationTests {

	@Test
	void contextLoads() {
	}

}
