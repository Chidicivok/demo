package com.chidi.studentmgtsys.controller;

import com.chidi.studentmgtsys.Service.EnrollmentService;
import com.chidi.studentmgtsys.dto.EnrollmentRequest;
import com.chidi.studentmgtsys.model.Enrollment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RestController
@RequestMapping("api/enrollment")
public class EnrollmentController {

    private EnrollmentService enrollmentService;

    // find all enrollments
    @GetMapping("find-all-enrollments")
    public List<Enrollment> findAllEnrollments() {
        return  enrollmentService.findAllEnrollments();
    }

    // find enrollment by id
    @GetMapping("find-enrollment-by-enrollement-id/{enrollmentId}")
    public Optional<Enrollment> findEnrollmentById(@PathVariable long enrollmentId){
        return enrollmentService.findEnrollmentByEnrollmentId(enrollmentId);
    }


    // find enrollment by student id
    @GetMapping("find-enrollment-by-student-id/{studentNumber}")
    public List<Enrollment> findEnrollmentsByStudentId(@PathVariable String studentNumber) {
        return enrollmentService.findEnrollmentByStudentNumber(studentNumber);
    }


    // find enrollment by course id
    @GetMapping("find-enrollment-by-course-id/{courseId}")
    public List<Enrollment> findEnrollmentsByCourseId(@PathVariable long courseId) {
        return enrollmentService.findEnrollmentByCourseId(courseId);
    }


    // save an enrollemnt record using dto request
    @PostMapping("save-enrollement")
    public String saveEnrollment(EnrollmentRequest enrollmentRequest) {
        return enrollmentService.enrollStudent(enrollmentRequest);
    }


}
