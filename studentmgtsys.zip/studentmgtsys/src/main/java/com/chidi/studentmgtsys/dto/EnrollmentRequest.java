package com.chidi.studentmgtsys.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EnrollmentRequest {

    @NotBlank(message = "Student id is required for creating enrollment record")
    private String student_id;

    @NotBlank(message = "Course id is required for creating enrollment record")
    private long course_id;
}
