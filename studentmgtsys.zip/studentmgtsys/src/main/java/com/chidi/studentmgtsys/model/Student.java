package com.chidi.studentmgtsys.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "student")
@NoArgsConstructor
@Setter
@Getter
public class Student {

    @Id
    @Column(name = "student_id")
    private String studentNumber;

    @NotBlank(message = "Name is required")
    @Size(min = 3, message = "Full name cannot be less than 3 characters")
    @Pattern(regexp = "^[A-Za-z]+$", message = "Name can only have alphabets")
    private String name;

    @Min(0)
    private double balance;

    @NotBlank(message = "The degree is needed(BSC/MASTERS/PHD)")
    private Degree degree;


    // for enrollment
    @OneToMany(mappedBy = "student")
    private List<Enrollment> enrollmentList = new ArrayList<>();

}
