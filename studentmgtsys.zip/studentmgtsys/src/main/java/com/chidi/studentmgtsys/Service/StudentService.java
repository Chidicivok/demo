package com.chidi.studentmgtsys.Service;


import com.chidi.studentmgtsys.model.Student;
import com.chidi.studentmgtsys.repository.StudentRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@Getter
@Setter
public class StudentService {

    private StudentRepository studentRepository;

    // find all students
    public List<Student> findAllStudents() {
        return  studentRepository.findAll();
    }

    // find student by ID
    public Optional<Student> findStudentById(String aStudentNumber){
        return studentRepository.findById(aStudentNumber);
    }

    // save student
    public String saveStudent(Student newStudent) {

        Optional<Student> toBeFoundStudent = studentRepository.findById(newStudent.getStudentNumber());

        if(toBeFoundStudent.isPresent()) return "Student already saved";

        studentRepository.save(newStudent);

        return "Student saved succesfully";

    }

    // delete
    public String deleteStudent(String aStudentNumber) {

        Optional<Student> toBeFoundStudent = studentRepository.findById(aStudentNumber);

        if(toBeFoundStudent.isEmpty()) return "Student does not exist";

        studentRepository.deleteById(aStudentNumber);
        return "Student deleted successfully";

    }

    // edit all other records apart from the student number
    public String updateStudentData(String aStudentNumber, Student newStudentRecord) {

        Optional<Student> toBeFoundStudent = studentRepository.findById(aStudentNumber);

        if(toBeFoundStudent.isEmpty()) return "Student not found";

        Student theStudent = (Student) toBeFoundStudent.get();

        // cahange other fields except the id
        theStudent.setName(newStudentRecord.getName());
        theStudent.setBalance(newStudentRecord.getBalance());
        theStudent.setDegree(newStudentRecord.getDegree());

        // save
        studentRepository.save(theStudent);

        return  "Student records has been updated";

    }



}
