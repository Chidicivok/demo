package com.chidi.studentmgtsys.repository;

import com.chidi.studentmgtsys.model.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {

    // list for enrollment by student number
    @Query(value = "SELECT * FROM enrollment WHERE student_id = :student_id", nativeQuery = true)
    List<Enrollment> findEnrollmentByStudentId(@Param("student_id") String student_id);


    // list for enrollment by course id
    @Query(value = "SELECT * FROM enrollment WHERE course_id = :course_id", nativeQuery = true)
    List<Enrollment> findEnrollmentByCourseId(@Param("course_id") long course_id);

    // boolean to prevent multiple enrollment of course and student repeatedly
    @Query(value = "SELECT COUNT(*) FROM enrollment WHERE student_id = :student_id AND course_id = :course_id", nativeQuery = true)
    int studentIsEnrolledInCourse(@Param("student_id") String student_id, @Param("course_id") long course_id);
}
