package com.chidi.studentmgtsys.Service;


import com.chidi.studentmgtsys.dto.EnrollmentRequest;
import com.chidi.studentmgtsys.model.Course;
import com.chidi.studentmgtsys.model.Enrollment;
import com.chidi.studentmgtsys.model.Student;
import com.chidi.studentmgtsys.repository.CourseRepository;
import com.chidi.studentmgtsys.repository.EnrollmentRepository;
import com.chidi.studentmgtsys.repository.StudentRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@Getter
@Setter
public class EnrollmentService {

    private EnrollmentRepository enrollmentRepository;
    private StudentRepository studentRepository;
    private CourseRepository courseRepository;

    // find all enrollment
    public List<Enrollment> findAllEnrollments() {
        return  enrollmentRepository.findAll();
    }

    // find by enrollment id
    public Optional<Enrollment> findEnrollmentByEnrollmentId(long anEnrollmentId) {
        return enrollmentRepository.findById(anEnrollmentId);
    }

    // save an enrollment record
    public String enrollStudent(EnrollmentRequest enrollmentRequest){

        Optional<Student> theStudent = studentRepository.findById(enrollmentRequest.getStudent_id());

        if(theStudent.isEmpty()) return "Student does not exist for enrollment";

        Optional<Course> theCourse = courseRepository.findById(enrollmentRequest.getCourse_id());

        if(theCourse.isEmpty()) return  "Course does not exist for enrollment";

        // if student is already enrolled in course. if more than 0 rows dont enroll
        boolean isAlreadyEnrolled =
                enrollmentRepository.studentIsEnrolledInCourse(enrollmentRequest.getStudent_id(), enrollmentRequest.getCourse_id()) > 0;

        if(isAlreadyEnrolled) return "This student is already enrolled in this course";

        // collect the student
        Student thatStudent = (Student) theStudent.get();

        // collect the course
        Course thatCourse = (Course) theCourse.get();

        LocalDate now = LocalDate.now();

        enrollmentRepository.save(new Enrollment(1, thatStudent, thatCourse, now));

        return "New enrollment recorded";

    }


    // find enrollment by studentid
//    @Query(value = "SELECT * FROM enrollment WHERE student_id = :student_id", nativeQuery = true)
    public List<Enrollment> findEnrollmentByStudentNumber( String student_id) {
        return enrollmentRepository.findEnrollmentByStudentId(student_id);
    }


    // find enrollment by courseid
  //  @Query(value = "SELECT * FROM enrollment WHERE course_id = :course_id", nativeQuery = true)
    public List<Enrollment> findEnrollmentByCourseId(long course_id) {
        return enrollmentRepository.findEnrollmentByStudentId(String.valueOf(course_id));
    }

}
