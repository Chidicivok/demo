package com.chidi.studentmgtsys.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "course")
@NoArgsConstructor
@Setter
@Getter
public class Course {

    @Id
    @Column(name = "course_id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long courseId;

    @NotBlank(message = "Course name is required")
    @Size(min = 4, message = "Course name should be longer than 4 characters")
    private String courseName;

    @NotBlank(message = "Course amount is required")
    @Positive(message = "Course amount must be a positive value")
    private double courseAmount;

    @OneToMany(mappedBy = "course")
    private List<Enrollment> enrollmentList = new ArrayList<>();

}
