package com.chidi.studentmgtsys.controller;

import com.chidi.studentmgtsys.Service.StudentService;
import com.chidi.studentmgtsys.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RestController
@RequestMapping("api/student")
public class StudentController {

    private StudentService studentService;


    // find all students
    @GetMapping("view-all-students")
    public List<Student> findAllStudents() {
        return studentService.findAllStudents();
    }


    // find specific student by id
    @GetMapping("find-student-by-id/{studentNumber}")
    public Optional<Student> findStudentById(@PathVariable String studentNumber) {
        return  studentService.findStudentById(studentNumber);
    }

    // save students
    @PostMapping("save-student")
    public String saveStudent(@RequestBody Student student ) {
        return studentService.saveStudent(student);
    }

    // delete a student
    @DeleteMapping("delete-student/{studentNumber}")
    public String deleteStudent(@PathVariable String studentNumber ) {
        return studentService.deleteStudent(studentNumber);
    }

    // update
    @PutMapping("update-student")
    public String updateStudentData(@PathVariable String studentNumber, @RequestBody Student student) {
        return studentService.updateStudentData(studentNumber,  student);
    }




}
