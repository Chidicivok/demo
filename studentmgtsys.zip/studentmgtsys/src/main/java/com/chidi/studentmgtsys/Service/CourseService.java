package com.chidi.studentmgtsys.Service;

import com.chidi.studentmgtsys.model.Course;
import com.chidi.studentmgtsys.repository.CourseRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
@Getter
@Setter
public class CourseService {

    private CourseRepository courseRepository;

    // find all courses
    public List<Course> findAllCourses() {
        return courseRepository.findAll();
    }

    // find by course id
    public Optional<Course> findCourseById(long aCourseId) {
        return courseRepository.findById(aCourseId);
    }

    // save a course
    public String saveCourse(Course newCourse) {
        Optional<Course> tobeFound = findCourseById(newCourse.getCourseId());

        if (tobeFound.isPresent()) return "Course already saved";

        courseRepository.save(newCourse);
        return "Course saved successfully";
    }


    // delete a course
    public String deleteCourse(long aCourseId) {

        Optional<Course> tobeFound = findCourseById(aCourseId);

        if(tobeFound.isEmpty()) return "Course not found";

        courseRepository.deleteById(aCourseId);
        return "Course deleted successfully";

    }

    // update a course record including the id
    public String updateCourseData(long aCourseId, Course newCourseRecord) {

        Optional<Course> tobeFound = findCourseById(aCourseId);

        if(tobeFound.isEmpty()) return  "Course not found";

        Course theCourse = (Course) tobeFound.get();
        theCourse.setCourseId(newCourseRecord.getCourseId());
        theCourse.setCourseName(newCourseRecord.getCourseName());
        theCourse.setCourseAmount(newCourseRecord.getCourseAmount());

        // save
        courseRepository.save(theCourse);
        return "Course record updated successfully";

    }



}
