package com.chidi.studentmgtsys.model;

public enum Degree {
    BSC,
    MASTERS,
    PHD
}
