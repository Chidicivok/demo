package com.chidi.studentmgtsys.controller;

import com.chidi.studentmgtsys.Service.CourseService;
import com.chidi.studentmgtsys.Service.StudentService;
import com.chidi.studentmgtsys.model.Course;
import com.chidi.studentmgtsys.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RestController
@RequestMapping("api/course")
public class CourseController {

    private CourseService courseService;

    // find all courses
    @GetMapping("view-all-courses")
    public List<Course> findAllCourses() {
        return courseService.findAllCourses();
    }

    // find course by id
    @GetMapping("view-course-by-id/{studentNumber}")
    public Optional<Course> findCourseById(@PathVariable long courseId) {
        return  courseService.findCourseById(courseId);
    }


    // save course
    @PostMapping("save-course")
    public String saveCourse(@RequestBody Course course ) {
        return courseService.saveCourse(course);
    }


    // delete a course
    @DeleteMapping("delete-course/{courseid}")
    public String deleteCourse(@PathVariable long courseId ) {
        return courseService.deleteCourse(courseId);
    }


    // update course
    @PutMapping("update-course")
    public String updateCourseData(@PathVariable long courseId, @RequestBody Course course) {
        return courseService.updateCourseData(courseId,  course);
    }




}










